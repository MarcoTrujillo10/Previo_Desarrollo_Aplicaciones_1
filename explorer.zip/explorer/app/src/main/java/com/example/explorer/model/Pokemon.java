package com.example.explorer.model;

public class Pokemon {
    private String name;
    private String url;
    private String imageUrl;
    private String gender;
    private String type;

    public Pokemon(String name, String url, String imageUrl, String gender, String type) {
        this.name = name;
        this.url = url;
        this.imageUrl = imageUrl;
        this.gender = gender;
        this.type = type;
    }

    public Pokemon(){}

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getGender() {
        return gender;
    }

    public String getType() {
        return type;
    }
}
