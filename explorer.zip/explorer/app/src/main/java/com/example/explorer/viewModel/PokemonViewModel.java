package com.example.explorer.viewModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.explorer.model.Pokemon;
import com.example.explorer.repository.PokemonRepository;

import java.util.List;

public class PokemonViewModel extends ViewModel {

    private PokemonRepository repository;

    private MutableLiveData<List<Pokemon>> pokemonList = new MutableLiveData<>();
    private MutableLiveData<String> error = new MutableLiveData<>();

    public PokemonViewModel() {
        repository = new PokemonRepository();
    }

    public LiveData<List<Pokemon>> getPokemonList() {
        return pokemonList;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void loadPokemonList() {
        repository.getPokemonList().enqueue(new retrofit2.Callback<com.example.explorer.model.PokemonResponse>() {
            @Override
            public void onResponse(retrofit2.Call<com.example.explorer.model.PokemonResponse> call, retrofit2.Response<com.example.explorer.model.PokemonResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    pokemonList.setValue(response.body().getResults());
                } else {
                    error.setValue("Error al cargar la lista de Pokémon");
                }
            }

            @Override
            public void onFailure(retrofit2.Call<com.example.explorer.model.PokemonResponse> call, Throwable t) {
                error.setValue("Error de conexión: " + t.getMessage());
            }
        });
    }
}

