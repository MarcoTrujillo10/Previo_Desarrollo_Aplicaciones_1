package com.example.explorer.api;


import com.example.explorer.model.PokemonResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("pokemon")
    Call<PokemonResponse> getPokemonList();
}
