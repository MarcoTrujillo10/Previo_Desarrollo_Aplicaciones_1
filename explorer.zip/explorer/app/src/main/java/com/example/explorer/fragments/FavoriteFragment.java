package com.example.explorer.fragments;

import androidx.fragment.app.Fragment;

public class FavoriteFragment extends Fragment {
}
