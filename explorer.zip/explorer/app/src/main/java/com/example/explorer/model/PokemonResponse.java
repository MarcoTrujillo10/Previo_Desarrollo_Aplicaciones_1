package com.example.explorer.model;

import java.util.List;

public class PokemonResponse {
    private List<Pokemon> pokemon;

    public List<Pokemon> getPokemon() {
        return pokemon;
    }

    public List<Pokemon> getResults() {
        return pokemon;
    }
}
