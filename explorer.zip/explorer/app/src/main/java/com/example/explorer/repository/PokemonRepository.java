package com.example.explorer.repository;

import com.example.explorer.api.ApiService;
import com.example.explorer.api.RetrofitClient;
import com.example.explorer.model.PokemonResponse;

import retrofit2.Call;

public class PokemonRepository {
    private ApiService apiService;

    public PokemonRepository() {
        apiService = RetrofitClient.getApiService();
    }

    public Call<PokemonResponse> getPokemonList() {
        return apiService.getPokemonList();
    }
}
