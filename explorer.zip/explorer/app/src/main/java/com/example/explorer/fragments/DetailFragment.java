package com.example.explorer.fragments;

import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.explorer.R;
import com.example.explorer.viewModel.PokemonViewModel;

public class DetailFragment extends Fragment {

    public DetailFragment() {
        super(R.layout.detail_fragment);
    }

    PokemonViewModel viewModel = new ViewModelProvider(this).get(PokemonViewModel.class);

    viewModel.getPokemonList().

}
